## <a name="setup">CloudIDOne Setup</a>

This section is for anyone working with the CloudIDOne SDK. it contains all topics related to authenticating users, single sign on, and content authorization checks.

### Requirements

The CloudIDOne SDK was built using Xcode Version 11 in Swift 5, for iOS 11-13

### <a name="sso_requirements">Special Apple SSO Requirements</a>

Before using the CloudIDOne SDK for single sign on (SSO), Apple must add the **video-subscriber entitlement** to your Apple provisioning profile. If you do not have this entitlement, please contact Synacor and we can help facilitate this requirement with Apple. Apple’s Video Subscriber Framework (VSA) is not yet officially supported in the simulator so development on device is required.

In addition to the entitlement being in your provisioning profile, you will also have to manually add the entitlement to your .entitlements file like so:

```
<key>com.apple.developer.video-subscriber-single-sign-on</key>
<true/>
```

### The two framework versions

Included are two .frameworks of CloudIdOne:

Use ```CloudIDOne_dev.framework``` for development on simulator / device

Use ```CloudIDOne_release.framework``` for submitting to the App Store.

It is worth noting that you should **only** have one of these .frameworks included in your project. You cannot include intel or simulator symbols when publishing to the App Store, as it will be automatically rejected.

You can customize your ```Framework Search Paths``` in XCode in your project's ```Build Settings``` to use the respective framework required for dev or release.

See also:
https://stackoverflow.com/questions/24150317/linking-a-framework-depending-on-build-or-debug-mode-in-xcode5

### Required Dependencies

You will need to ensure that the Cloud Id One framework has it's dependencies.
If you are using CocoaPods, add these

```
pod 'RxSwift',        '~> 5.0'
pod 'RxCocoa',        '~> 5.0'
pod 'RxSwiftExt',     '~> 5.0'
pod 'ObjectMapper',   '~> 3.4'
pod 'SwiftyJSON',     '~> 5.0'
pod 'SWXMLHash',      '~> 4.7'
pod 'KeychainAccess', '~> 3.1'
```

Otherwise you will have to manually add these dependencies and their corresponding versions.

[RXSwift | https://github.com/ReactiveX/RxSwift](https://github.com/ReactiveX/RxSwift)

[RxCocoa | https://github.com/ReactiveX/RxSwift/tree/master/RxCocoa](https://github.com/ReactiveX/RxSwift/tree/master/RxCocoa)

[RxSwiftExt | https://github.com/RxSwiftCommunity/RxSwiftExt](https://github.com/RxSwiftCommunity/RxSwiftExt)

[ObjectMapper | https://github.com/tristanhimmelman/ObjectMapper](https://github.com/tristanhimmelman/ObjectMapper)

[SwiftyJSON | https://github.com/SwiftyJSON/SwiftyJSON](https://github.com/SwiftyJSON/SwiftyJSON)

[SWXMLHash | https://github.com/drmohundro/SWXMLHash](https://github.com/drmohundro/SWXMLHash)

[KeychainAccess | https://github.com/kishikawakatsumi/KeychainAccess](https://github.com/kishikawakatsumi/KeychainAccess)

### Installation
The CloudIDOne framework can be added to Xcode like any other framework. The easiest way to do this is: Drag the .framework file into your Xcode project.

In the following dialog, ensure that:

* “Copy items if needed” is checked
* That, at a minimum, your main application target is selected
* Click “Add”

A few additional steps need to be taken to ensure the SDK builds in your project correctly:

* Click your project in the Project Navigator.
* Select your application target in the main content window.
* In the “General” tab, remove `CloudIDOne.framework` from the “Linked Frameworks and Libraries” section, if it was added there automatically.
* Click the “+” in the “Embedded Binaries” section, and select SynacorCloudIdPlus.framework in the popup that results. This should properly add it to both the “Embedded Binaries” section and “Linked Frameworks and Libraries”

If you’re developing your application in Objective-C, you’ll need to do one further thing before the project will compile correctly. Following the same two steps listed previously:
Select the “Build Settings” tab.
In the “Build Options” section, ensure that “Embedded Content Contains Swift Code” is set to “Yes”; this will embed the necessary Swift libraries into your project automatically, if they are not already embedded.

### Info.plist

The final step in setting up the SDK, involves adding some keys to you application’s info.plist.

* Add App Transport Security Settings key > Allow Arbitrary Loads set to YES
* Add Privacy - TV Provider Usage Description Key > Enter a description of how your application will use their private information.
 
You should now be able to use the CloudIDOne SDK in your iOS application!


## <a name="using">Using CloudIDOne</a>


### Importing the SDK
The first step to using the CloudIDOne SDK in your project is properly importing the file:

**Swift:** `import CloudIDOne`

**Objective-C:** `#import <CloudIDOne/CloudIDOne-Swift.h>`

### Synacor Provided Configuration Values:

In order to use CloudId in an application, you are going to need some configuration values provided by Synacor:

* **client**: an identifier representing your application as it attempts to log a user in.
* **provider**: an identifier representing the 3rd party identity provider we will be working with.

### Configuration Objects:

To get started using CloudIDOne you are going to need to provide all of the configuration values it needs to accomplish it's tasks. The SDK gives you multiple way to provide these values.

Here is an example of instantiating a Config object directly in Swift:

```
let cloudIDConfig = CloudID.Config(
	webConfig: WebCloudID.Config(
		client: "myclient",
		identityProvider: "myprovider"
		keychainService: "CloudIDOne"
	),
	ssoConfig: SSOCloudID.Config(
		isEnabled: false
	)
)
```

In the example above, we are creating a `CloudID.Config` object that is specifying which client and provider to use. Those are the values that will supplied to you from Synacor. The `keychainService` argument is a unique identifier used with the iOS keychain to store secure data. You may provide any value for this, but a reverse domain name representing your application is a best practice for this (eg:"com.company.app.CloudIDOne").

You'll notice that the Config object is divided up into 2 sub-objects:

* webConfig: Config parameters for standard CloudID login service.
* ssoConfig: Config paramters for working with Apple Single Sign-On.

#### Configuration from a JSON file

The SDK gives you a simple way to define your Config object in a JSON file and then load it from your Bundle. Here is an example of the same configuration defined in JSON named `cloudid_config.json`:

```
{
  "web_config": {
    "client": "myclient",
    "identity_provider": "myprovider",
    "keychain_service": "CloudIDOne"
  },
  "sso_config": {
    "is_enabled": false
  }
}
```

This file can be loaded uses the SDK like so:

```
let cloudIDConfig = CloudID.cloudID(
	forConfigAt: Bundle.main.url(
		forResource: "cloudid_config",
		withExtension: "json"
	)!
 )
```

#### Configuration for Apple SSO

SSO is based on the new framework called Video Subscriber Account (VSA) that was introduced in iOS 10.0 and tvOS 10.0.

If you want to work with Apple SSO you will have to ensure [that you have met all the requirements to do so](#sso_requirements). Now you can decorate the ssoConfig object with more details that will allow you to utilize Apple's SSO system.

CloudIDOne will attempt to use Apple SSO if configured to do so, but if the SDK determines that it is not possible, then it will fallback to using standard CloudID authentication.

The following is a full SSO configuration defined in JSON:

```
{
  "web_config": {
    "client": "myclient",
    "identity_provider": "myprovider",
    "keychain_service": "CloudIDOne"
  },
  "sso_config": {
    "is_enabled": true,
    "channel_identifier": "com.apple.VideoSubscriberAccount.SAML",
    "supported_account_provider_identifiers":["gvtc_auth-gateway_net"],
     "attribute_names": [
      "uid",
      "mvpd_hhid",
      "mvpd_uuid",
      "is_hoh",
      "household_id",
      "guid"
    ]
  }
}
```

Above, we provide the same standard CloudID configuration values we did previously, but this time there is much more to the sso_config now that it is enabled.

First, the `channel_identifier` value is a fixed String `com.apple.VideoSubscriberAccount.SAML`.

The `supported_account_provider_identifiers` gives us a way to filter all of the possible account providers. The SDK can present a list of all available account providers and prompt the user to select one, but by populating this list, we limit it to only the types we want to deal with.

`attribute_names` is a list of attributes that is to be returned in the SAML metadata response. This parameter is optional for Synacor IDPs, all available attributes are returned.


### Constructing the Cloud ID SDK Object
The Cloud ID SDK object is used to perform API related calls. You define and initialize the object as follows:

```
let cloudID = CloudID(config: 
	CloudID.cloudID(
		forConfigAt: Bundle.main.url(
			forResource: "cloudid_config",
			withExtension: "json"
		)!
 	)
 )
```

### <a name="cloudid_methods">CloudID Methods</a>

The methods listed here trigger processes for the SDK, but all [results are handled using Reactive streams](#cloudid_streams).

#### `cloudID.logIn()`

This method starts the login process. Depending on the configuration provided to the CloudID object, this can kick off different processes. 

If standard CloudID web login is being used, this will launch a login form, wait for input from the user, then report back on sucess or failure.

If SSO Login is being used, then the Apple SSO system will take over and wal the user through the process os selecting or creating a new account. The result of that process will be reported back.

####`cloudID.logOut()`

This method start the process of logging out a User if one is currently logged in. If you are using Apple SSO it is important to know that the SSO account will not be removed from the device. That must be done manually in Apple Account Settings.

####`cloudID.checkAccess()`

This method can be called at anytime to see if the status of the logged in user has changed. This can happen if the user is no longer seen as authenticated with the server, or if the user removes the Apple SSO account that is currently being used by the application.


### <a name="cloudid_streams">Handling responses with Reactive Streams</a>

All of the [methods listed above](#cloudid_methods) trigger action, but the result of that action is expressed in emissions from a set of Reactive streams available for you to subscribe to.

The CloudIDOne SDK uses [RxSwift](https://github.com/ReactiveX/RxSwift). It is recommended that you familiarize yourself with the basics of RX before continuing.
 
#### `cloudID.user`

This is an Observable that emits an Optional User. If the User has a value, that you can consider the end-user logged in. If it is nil, then the user is logged out.

To capture the state of the user, use the following code:

```
cloudID.user.subscribe(onNext: { user in
    //do something with user.
})
```

#### `cloudID.userInteractionRequired`

This observable stream is used to present view controllers to the end user in response to action being taken by the SDK. View controller references are passed to you, and you are instructed to either present or remove them. You have control over how they are presented.


Here's a simple example of handling user interaction from an AppDelegate:

```
cloudID.userInteractionRequired
	.filter({ $0.action == .present })
	.subscribe(onNext: { [unowned self] viewController in
        self.presentLoginViewController(viewController)
    })
	
cloudID.userInteractionRequired
	.filter({ $0.action == .dismiss })
	.subscribe(onNext: { [unowned self] viewController in
        self.dismissLoginViewController(viewController)
    })

```

#### `cloudID.errors`

This observable stream allows you to handle or report on any errors (Swift.Error) that occur during any process:

```
cloudID.errors.subscribe(onNext: { error in
    //do something with the error.
})

```

#### `cloudID.entitlements(for user: AnyUser, channel: String)`

This observable stream is called as a method and is used to check entitlements for a user.

```
cloudID.entitlements(for: user, channel: "ESPN")
.subscribe(
    onNext: { authz in
        // handle entitlement response.
    },
    onError: { error in
        // handle any error that amy occur.
    }
)
```
